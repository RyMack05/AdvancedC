#ifndef NAME_LENGTH_H
#define NAME_LENGTH_H

int name_length(const char* name);

#endif // NAME_LENGTH_H
